echo "Hello $USER. Running ExampleHomework ..."
echo "Date: $(date)"
sudo rm -vf *.o
./ExampleHomework
