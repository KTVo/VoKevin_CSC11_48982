echo "Hello $USER. we are going to run Project 2.\n"
echo "Today is $(date)"
echo "Current working directory : $(pwd)"
sudo rm -vf *.o
sudo ./Project2
